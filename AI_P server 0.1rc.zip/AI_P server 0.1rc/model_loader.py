from llama_cpp import Llama
import threading
from config import Config
import sys

class ModelSingleton:
    Isinstance = None
    lock = threading.Lock()
    def __new__(cls):
        with cls.lock:
            if not cls.Isinstance:
                cls.Isinstance = super().__new__(cls)
                cls.Isinstance.init_model()
            return cls.Isinstance

    def init_model(self):
        self.model =  Llama(
    model_path=Config.modelPath,
    n_ctx=2**14,  # Контекстное окно
    n_gpu_layers=Config.n_gpu_layers,
    n_batch=Config.n_batch,
    n_threads=Config.n_threads,
    verbose=False,
    stream=False
        )
        self.lock = threading.Lock()

model = ModelSingleton().model
model_lock = ModelSingleton().lock