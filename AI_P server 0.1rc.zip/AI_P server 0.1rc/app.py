from flask import Flask, request, jsonify
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from model_loader import model, model_lock
from session_manager import session_manager
import uuid
from config import Config
import logging
from logging.handlers import RotatingFileHandler
import json
app = Flask(__name__)
import re
#from flask_login import login_required

USERS_FILE = Config.USERS_FILE

# логи
logger = logging.getLogger('my_app')
logger.setLevel(logging.INFO)

# обработчик для всех логов
handler = RotatingFileHandler(
    'app.log',
    maxBytes=1000000,
    backupCount=3,
    encoding='utf-8'
)

handler.setFormatter(logging.Formatter(
    '%(asctime)s - %(levelname)s - %(message)s'
))
logger.addHandler(handler)

llama_logger = logging.getLogger('llama.cpp')
llama_logger.propagate = False  # Отключаем передачу родительским логгерам
llama_logger.addHandler(handler)
llama_logger.setLevel(logging.INFO)

def md_to_html(text):
    # Обработка заголовков
    text = re.sub(r'^#\s+(.*?)\s*$', r'<h1>\1</h1>', text, flags=re.MULTILINE)
    text = re.sub(r'^##\s+(.*?)\s*$', r'<h2>\1</h2>', text, flags=re.MULTILINE)

    # Обработка жирного и курсива
    text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
    text = re.sub(r'\*(.*?)\*', r'<i>\1</i>', text)

    # Обработка списков
    lines = text.split('\n')
    in_list = False
    result = []

    for line in lines:
        # Нумерованные списки
        if re.match(r'^\d+\.\s+', line):
            if not in_list:
                result.append('<ol>')
                in_list = True
            item = re.sub(r'^\d+\.\s+(.*)', r'<li>\1</li>', line)
            result.append(item)
        # Маркированные списки
        elif re.match(r'^-\s+', line):
            if not in_list:
                result.append('<ul>')
                in_list = True
            item = re.sub(r'^-\s+(.*)', r'<li>\1</li>', line)
            result.append(item)
        else:
            if in_list:
                result.append('</ol>' if re.search(r'^\d+\.', lines[lines.index(line) - 1]) else '</ul>')
                in_list = False
            result.append(line)

    if in_list:
        result.append('</ol>' if re.search(r'^\d+\.', lines[-1]) else '</ul>')

    text = '\n'.join(result)

    # Обработка переносов
    text = text.replace('\n\n', '<br>')
    print(text)

    return text

# запуск сервиса
app = Flask(__name__)
# лимит запросов к модели
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    storage_uri="memory://",
    default_limits=["200 per hour",]
)

# общие логи
handler = RotatingFileHandler(
    'app.log',
    maxBytes=1000000,
    backupCount=3
)
handler.setLevel(logging.INFO)
app.logger.addHandler(handler)

def load_users():
    with open(USERS_FILE, 'r') as f:
        return json.load(f)

def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=4)

def find_user_by_token(token):
    users = load_users()
    for username, data in users.items():
        if data.get('token') == token:
            return username
    return None


@app.route('/register', methods=['POST'])
@limiter.limit("20 per minute")
def register():
    try:
        data = request.json
        user_ip = request.remote_addr
        users = load_users()

        # Получаем первый ключ из JSON как username
        username = next(iter(data.keys())) if data else None
        if not username:
            logger.warning(f"[ОШИБКА РЕГИСТРАЦИИ] - пустой username: IP - {user_ip}")
            return jsonify({"error": "Username required"}), 400

        if username in users:
            logger.warning(
                f"[ОШИБКА РЕГИСТРАЦИИ] - пользователь уже существует: IP - {user_ip} ###### Username - {username}")
            return jsonify({"error": "вы уже зарегистрированы"}), 400

        # Получаем пароль из вложенного объекта
        password = data[username].get('password')
        if not password:
            logger.warning(f"[ОШИБКА РЕГИСТРАЦИИ] - пароль не указан: IP - {user_ip} ###### Username - {username}")
            return jsonify({"error": "Password required"}), 400

        # Генерируем токен
        user_token = str(uuid.uuid4())

        # Сохраняем пользователя
        users[username] = {
            "password": password,
            "token": user_token
        }
        save_users(users)

        # Формируем начальную историю
        initial_history = [{
            "role": Config.role_list[0],
            "content": Config.system_prompt
        }]

        # Инициализируем историю
        session_manager.save_history(username, initial_history)

        logger.info(f"[РЕГИСТРАЦИЯ УСПЕШНА]: IP - {user_ip} ###### Username - {username}")
        return jsonify({
            "success": True,
            "token": user_token,
            "history": initial_history  # Добавляем историю в ответ
        })

    except Exception as e:
        logger.error(f"[ОШИБКА РЕГИСТРАЦИИ]: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500


@app.route('/login', methods=['POST'])
@limiter.limit("20 per minute")
def login():
    try:
        data = request.json
        user_ip = request.remote_addr

        # Проверяем наличие ключей
        if 'username' not in data or 'password' not in data:
            logger.warning(f"[ОШИБКА ВХОДА] - неверный формат запроса: IP - {user_ip}")
            return jsonify({"error": "Неверный формат запроса"}), 400

        username = data['username']
        password = data['password']
        users = load_users()

        # Проверяем существование пользователя
        if username not in users:
            logger.warning(f"[ОШИБКА ВХОДА] - пользователя не существует: IP - {user_ip}")
            return jsonify({"error": "Пользователь не найден"}), 400

        user = users[username]

        # Проверяем пароль
        if user['password'] != password:
            logger.warning(f"[ОШИБКА ВХОДА] - неверный пароль: IP - {user_ip} ###### Username - {username}")
            return jsonify({"error": "Неверный пароль"}), 401

        logger.info(f"[УСПЕШНЫЙ ВХОД]: IP - {user_ip} ###### Username - {username}")

        user_history = session_manager.load_history(username)

        # Преобразуем историю в список словарей
        formatted_history = [
            {"role": msg["role"], "content": msg["content"]}
            for msg in user_history
        ]
        res = {
            "success": True,
            "token": user['token'],
            "history": formatted_history  # Правильный формат
        }
        print(res)
        return jsonify(res)

    except Exception as e:
        logger.error(f"[ОШИБКА ВХОДА]: {str(e)}")
        return jsonify({"error": "Внутренняя ошибка сервера"}), 500

@app.errorhandler(429)
def login_limit_handler(e):
    user_ip = request.remote_addr

    logger.warning(f"[ПРЕВЫШЕНИЕ ЛИМИТА] - IP: {user_ip}")
    return jsonify({"error": str(e)}), 429


@app.route('/chat', methods=['POST'])
@limiter.limit("10 per minute")
def chat():
    try:
        data = request.get_json()
        user_token = data.get('token')

        # Находим пользователя по токену
        username = find_user_by_token(user_token)
        if not username:
            logger.warning(f"[ОШИБКА] Неверный токен: {user_token}")
            return jsonify({"error": "Неверный токен"}), 401

        # Загружаем историю пользователя
        history = session_manager.load_history(username)
        print(data)
        user_input = data['question']


        # Добавляем сообщение пользователя в историю
        history.append({
            "role": Config.role_list[1],  # user
            "content": user_input
        })

        # Генерация ответа
        with model_lock:
            response = model.create_chat_completion(
                messages=history,

                **Config.MODEL_PARAMS
            )
        # Добавляем ответ ассистента в историю
        ai_response = response['choices'][0]['message']['content']
        ai_response = md_to_html(ai_response)
        history.append({
            "role": Config.role_list[2],  # assistant
            "content": ai_response
        })

        # Сохраняем обновленную историю
        session_manager.save_history(username, history)
        print(ai_response)
        return jsonify({
            "answer": ai_response,
            "status": "success",
            "history": history  # Добавляем полную историю в ответ
        })

    except Exception as e:
        print(e)
        logger.error(
            f"[ОШИБКА]: IP - {request.remote_addr}  ###### текст ошибки - {str(e)}"
        )
        print(e)
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(
        host=Config.SERVER['host'],
        port=Config.SERVER['port'],
        debug=Config.SERVER['debug']
    )